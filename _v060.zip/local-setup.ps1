#Requires -Version 5.1

<#
.SYNOPSIS
    Lokale setup voor microsoft-admin-mcp op deze machine.
.DESCRIPTION
    Dit script staat in .gitignore en gaat dus NOOIT mee naar GitHub, omdat het
    tenantgegevens bevat. Het doet twee dingen:

    1. Registreert tenants in %USERPROFILE%\.microsoft-admin-mcp\environments.json
       (buiten het repository). Bestaande tenants blijven staan; alleen
       ontbrekende worden toegevoegd.
    2. Voegt de microsoft-admin server toe aan de Claude Desktop configuratie
       (%APPDATA%\Claude\claude_desktop_config.json) als die er nog niet staat.

    Draai het script en herstart daarna Claude Desktop volledig. Vraag dan in
    een chat: "log in op vworld" en de browser opent voor de aanmelding.
.EXAMPLE
    PS> .\local-setup.ps1
.NOTES
    Auteur: Xander Oortgiesen (gegenereerd door Claude)
    Versie: 1.0
#>

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Pas hier je tenants aan (dit bestand blijft lokaal) ---
$tenants = @(
    [pscustomobject]@{
        name        = 'vworld'
        tenantId    = 'vworld.nl'
        authMode    = 'interactive'
        description = 'vWorld Intune tenant'
    }
)

function Write-Step { param([string]$Text) Write-Host "==> $Text" -ForegroundColor Cyan }

try {
    # --- 1. Tenants registreren in het gebruikersprofiel ---
    $envDir  = Join-Path $env:USERPROFILE '.microsoft-admin-mcp'
    $envFile = Join-Path $envDir 'environments.json'
    New-Item -Path $envDir -ItemType Directory -Force | Out-Null

    $existing = @()
    if (Test-Path $envFile) {
        $existing = @((Get-Content $envFile -Raw | ConvertFrom-Json))
    }

    $added = @()
    foreach ($tenant in $tenants) {
        if ($existing | Where-Object { $_.name -eq $tenant.name }) {
            Write-Host "Tenant '$($tenant.name)' bestaat al, overgeslagen."
        } else {
            $existing += $tenant
            $added += $tenant.name
        }
    }

    if ($added.Count -gt 0) {
        $json = ConvertTo-Json @($existing) -Depth 5
        if (@($existing).Count -eq 1) { $json = "[`n$json`n]" }
        # WriteAllText schrijft UTF-8 zonder BOM; de server weigert JSON met BOM.
        [IO.File]::WriteAllText($envFile, $json)
        Write-Step "Toegevoegd aan $envFile : $($added -join ', ')"
    } else {
        Write-Step "Geen nieuwe tenants om toe te voegen ($envFile)."
    }

    # --- 2. Claude Desktop configuratie ---
    # Een Microsoft Store installatie leest zijn config uit een virtuele AppData-map
    # (LOCALAPPDATA\Packages\Claude_...\LocalCache\Roaming\Claude). We schrijven daarom
    # naar elke locatie die bestaat, zodat het op elk type installatie werkt.
    $cfgFiles = @()
    $normal = Join-Path $env:APPDATA 'Claude\claude_desktop_config.json'
    if (Test-Path (Split-Path $normal)) { $cfgFiles += $normal }
    Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Packages') -Directory -Filter '*laude*' -ErrorAction SilentlyContinue | ForEach-Object {
        $storeDir = Join-Path $_.FullName 'LocalCache\Roaming\Claude'
        if (Test-Path $storeDir) { $cfgFiles += (Join-Path $storeDir 'claude_desktop_config.json') }
    }
    if ($cfgFiles.Count -eq 0) { $cfgFiles = @($normal) }

    foreach ($cfgFile in $cfgFiles) {
        $cfg = if (Test-Path $cfgFile) { (Get-Content $cfgFile -Raw).TrimStart([char]0xFEFF) | ConvertFrom-Json } else { [pscustomobject]@{} }

        if ($null -eq $cfg.PSObject.Properties['mcpServers']) {
            $cfg | Add-Member -MemberType NoteProperty -Name 'mcpServers' -Value ([pscustomobject]@{})
        }

        if ($null -ne $cfg.mcpServers.PSObject.Properties['microsoft-admin']) {
            Write-Step "Claude Desktop kent de server al ($cfgFile)."
        } else {
            $server = [pscustomobject]@{
                command = 'npx'
                args    = @('-y', 'github:xchello/microsoft-admin-mcp')
            }
            $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name 'microsoft-admin' -Value $server
            New-Item -Path (Split-Path $cfgFile) -ItemType Directory -Force | Out-Null
            # WriteAllText schrijft UTF-8 zonder BOM; sommige JSON-parsers weigeren een BOM.
            [IO.File]::WriteAllText($cfgFile, (ConvertTo-Json $cfg -Depth 10))
            Write-Step "Server toegevoegd aan $cfgFile"
        }
    }

    Write-Host ""
    Write-Host "Klaar! Herstart Claude Desktop volledig (ook uit het systeemvak)." -ForegroundColor Green
    Write-Host "Vraag daarna in een chat: 'log in op vworld' voor de browser-aanmelding." -ForegroundColor Green
}
catch {
    $err = $_
    Write-Error "Setup mislukt: $($err.Exception.Message)"
}
